import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useFarmers } from "@/store/farmers";
import { provinces, districtsByProvince } from "@/lib/zimbabwe-geo";

import type { Crop, Livestock } from "@/types";

const cropOptions: Crop[] = ["Maize", "Tobacco", "Cotton", "Soybean"];
const livestockOptions: Livestock[] = ["Cattle", "Goats", "Sheep"];

const schema = z.object({
  firstName: z.string().min(1, "First name required"),
  lastName: z.string().min(1, "Last name required"),
  phone: z.string().min(1, "Phone required"),
  provinceId: z.string().min(1, "Province required"),
  districtId: z.string().min(1, "District required"),
  crops: z.array(z.string()).min(1, "Select at least one crop"),
  farmSizeHa: z.coerce.number().min(0.01),
  gender: z.enum(["M", "F", "Other"]),
  dob: z.string().min(1),
  nationalId: z.string().min(1),
  wardId: z.string().optional(),
  villageId: z.string().optional(),
  householdId: z.string().optional(),
  gpsLat: z.string().optional(),
  gpsLng: z.string().optional(),
  livestock: z.array(z.string()).optional(),
});

type FormValues = z.infer<typeof schema>;

export const Route = createFileRoute("/_authenticated/farmers/simple")({
  component: SimpleFarmerPage,
});

function SimpleFarmerPage() {
  const navigate = useNavigate();
  const addFarmer = useFarmers((s: any) => s.addFarmer);
  const [isLoading, setIsLoading] = React.useState(false);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      firstName: "",
      lastName: "",
      phone: "",
      provinceId: "",
      districtId: "",
      farmSizeHa: 1,
      gender: "M",
      dob: "",
      nationalId: "",
      crops: [],
      livestock: [],
    },
  });

  const provinceId = watch("provinceId");
  const selectedCrops = watch("crops");

  const handleSubmitForm = async (data: FormValues) => {
    try {
      setIsLoading(true);
      console.log("Submitting form data:", data);
      
      const farmer = addFarmer(data as any);
      console.log("Farmer created:", farmer);
      
      toast.success("Farmer registered!");
      navigate({ to: "/farmers/$farmerId", params: { farmerId: farmer.id } });
    } catch (err) {
      console.error("Error:", err);
      toast.error("Failed to register farmer");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleCrop = (crop: Crop) => {
    const current = selectedCrops || [];
    if (current.includes(crop)) {
      setValue("crops", current.filter((c) => c !== crop));
    } else {
      setValue("crops", [...current, crop]);
    }
  };

  return (
    <div className="flex flex-col">
      <PageHeader title="Register Farmer (Simple)" description="Quick farmer registration" />

      <div className="mx-auto w-full max-w-2xl p-6">
        <form onSubmit={handleSubmit(handleSubmitForm)} className="space-y-6">
          <Card className="p-6">
            <h3 className="mb-4 font-semibold">Basic Info</h3>
            
            <div className="space-y-4">
              <div>
                <Label>First Name</Label>
                <Input {...register("firstName")} />
                {errors.firstName && <p className="text-red-500 text-sm">{errors.firstName.message}</p>}
              </div>

              <div>
                <Label>Last Name</Label>
                <Input {...register("lastName")} />
                {errors.lastName && <p className="text-red-500 text-sm">{errors.lastName.message}</p>}
              </div>

              <div>
                <Label>Phone</Label>
                <Input {...register("phone")} />
                {errors.phone && <p className="text-red-500 text-sm">{errors.phone.message}</p>}
              </div>

              <div>
                <Label>Gender</Label>
                <select {...register("gender")} className="border rounded px-3 py-2 w-full">
                  <option value="M">Male</option>
                  <option value="F">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <Label>Date of Birth</Label>
                <Input type="date" {...register("dob")} />
              </div>

              <div>
                <Label>National ID</Label>
                <Input {...register("nationalId")} />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="mb-4 font-semibold">Location</h3>

            <div className="space-y-4">
              <div>
                <Label>Province</Label>
                <select {...register("provinceId")} className="border rounded px-3 py-2 w-full">
                  <option value="">Select...</option>
                  {provinces.map((p: any) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
                {errors.provinceId && <p className="text-red-500 text-sm">{errors.provinceId.message}</p>}
              </div>

              <div>
                <Label>District</Label>
                <select 
                  {...register("districtId")}
                  disabled={!provinceId}
                  className="border rounded px-3 py-2 w-full disabled:opacity-50"
                >
                  <option value="">Select...</option>
                  {provinceId && districtsByProvince(provinceId).map((d: any) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
                {errors.districtId && <p className="text-red-500 text-sm">{errors.districtId.message}</p>}
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="mb-4 font-semibold">Farm Info</h3>

            <div className="space-y-4">
              <div>
                <Label>Farm Size (hectares)</Label>
                <Input type="number" step="0.01" {...register("farmSizeHa")} />
              </div>

              <div>
                <Label>Crops</Label>
                <div className="space-y-2">
                  {cropOptions.map((crop) => (
                    <label key={crop} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={selectedCrops?.includes(crop) || false}
                        onChange={() => toggleCrop(crop)}
                      />
                      {crop}
                    </label>
                  ))}
                </div>
                {errors.crops && <p className="text-red-500 text-sm">{errors.crops.message}</p>}
              </div>
            </div>
          </Card>

          <div className="flex gap-3 justify-end">
            <Button variant="outline" asChild>
              <Link to="/farmers">Cancel</Link>
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Registering..." : "Register Farmer"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
