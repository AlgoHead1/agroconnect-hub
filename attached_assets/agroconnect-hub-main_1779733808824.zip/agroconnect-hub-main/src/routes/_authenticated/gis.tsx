import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/app/page-header";
import { Card } from "@/components/ui/card";
import { MapPin, Layers, Activity } from "lucide-react";

export const Route = createFileRoute("/_authenticated/gis")({
  component: GisPage,
});

function GisPage() {
  return (
    <div className="flex flex-col">
      <PageHeader
        title="GIS Overview"
        breadcrumb="Insights"
        description="Geographic intelligence for farmer density, distribution coverage and crop heatmaps."
      />
      <div className="p-6 space-y-4">
        <div className="grid gap-4 lg:grid-cols-4">
          <Card className="p-4 flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 text-primary"><MapPin className="h-4 w-4" /></span>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Layers</p>
              <p className="text-sm font-semibold">Farmer density · Distribution · Crops</p>
            </div>
          </Card>
          <Card className="p-4 flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-earth/10 text-earth"><Layers className="h-4 w-4" /></span>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Boundary data</p>
              <p className="text-sm font-semibold">Province · District · Ward</p>
            </div>
          </Card>
          <Card className="p-4 flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-success/10 text-success"><Activity className="h-4 w-4" /></span>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Engine</p>
              <p className="text-sm font-semibold">Leaflet.js — ready to wire</p>
            </div>
          </Card>
          <Card className="p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Coverage</p>
            <p className="text-lg font-semibold tabular-nums">17 / 60 districts</p>
            <div className="mt-1.5 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary rounded-full" style={{ width: "28%" }} />
            </div>
          </Card>
        </div>

        <Card className="overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h3 className="text-sm font-semibold">GIS Layer Container</h3>
            <p className="text-xs text-muted-foreground">Leaflet integration is deferred for this demo — use the GIS module link from the dashboard to view coverage metrics and exports.</p>
          </div>
          <div className="h-[460px] relative bg-gradient-to-br from-primary/5 via-background to-earth/5">
            <div className="absolute inset-0" style={{
              backgroundImage: "radial-gradient(circle at 20% 30%, var(--primary) 2px, transparent 3px), radial-gradient(circle at 35% 60%, var(--earth) 2px, transparent 3px), radial-gradient(circle at 55% 25%, var(--primary) 2px, transparent 3px), radial-gradient(circle at 65% 70%, var(--earth) 2px, transparent 3px), radial-gradient(circle at 80% 45%, var(--primary) 2px, transparent 3px), radial-gradient(circle at 45% 80%, var(--earth) 2px, transparent 3px), radial-gradient(circle at 25% 75%, var(--primary) 2px, transparent 3px)",
              opacity: 0.4,
            }} />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center bg-card/90 backdrop-blur rounded-lg border border-border px-6 py-4 shadow-sm">
                <MapPin className="h-7 w-7 text-primary mx-auto" />
                <p className="text-sm font-semibold mt-2">Zimbabwe — GIS layer container</p>
                <p className="text-xs text-muted-foreground mt-1 max-w-xs">
                  Tile provider and choropleth layers can be enabled for full spatial visuals; for the demo we show coverage and export-ready metrics.
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
